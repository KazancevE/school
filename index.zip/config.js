var config = {
    TOKEN: '6543794835:AAF83bIzXXmm2zMiT7Z5KVj6chvg-bjEzY0',
    CHAT_ID: '-1002074817787',
    URI_API: `https://api.telegram.org/bot${TOKEN}/sendMessage`,
}